package com.example.gramofer.service;

import com.example.gramofer.model.Ploca;
import com.example.gramofer.repo.Ploce_Repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Ploce_Service {

    @Autowired
    Ploce_Repo repo;

    public List<Ploca> dohvati_sve_ploce() {
        return repo.findAll();
    }

    public void dodaj_plocu(Ploca ploca) {
        repo.save(ploca);
    }

    public void izmijeni_plocu(Ploca ploca) {
        repo.save(ploca);
    }

    public void obrisi_plocu(int id) {
        repo.deleteById(id);
    }
}
