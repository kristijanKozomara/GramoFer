package com.example.gramofer.model;

public enum Stanje_Goldmine {
    MINT,NEAR_MINT,EXCELLENT,VERY_GOOD,GOOD,POOR,FAIR
}
