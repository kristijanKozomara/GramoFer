package com.example.gramofer.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Stack;
@Component
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor

public class Ploca {
    @Id
    private int id;
    private int user_id;
    private String oznaka_izdanja;
    private String album;
    private String izvodac;
    private int godina_izdanja;
    private String glazbeni_zanr;
    private Stanje_Goldmine stanje_ploce;
    private Stanje_Goldmine stanje_omota;
    private byte[] omot1;
    private byte[] omot2;
    private byte[] ploca3;
    private byte[] ploca4;
    private String dodatan_opis;

}
